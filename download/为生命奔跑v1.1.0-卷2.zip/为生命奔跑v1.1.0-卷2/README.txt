1) Extract the whole zip

2) Open "为生命奔跑.exe" to start the app.

Open "licenses.html" for information regarding open source software used by the app.